-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: tenantdemo-south-laundry
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_loyalties`
--

DROP TABLE IF EXISTS `customer_loyalties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_loyalties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0 COMMENT 'Total loyalty points earned',
  `stamps` int(11) NOT NULL DEFAULT 0 COMMENT 'Number of stamps (1 per order)',
  `tier` enum('bronze','silver','gold','platinum') NOT NULL DEFAULT 'bronze' COMMENT 'Loyalty tier based on spending',
  `lifetime_spent` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Total amount spent lifetime',
  `last_earned_at` timestamp NULL DEFAULT NULL COMMENT 'Last time points were earned',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_loyalties_customer_id_unique` (`customer_id`),
  CONSTRAINT `customer_loyalties_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_loyalties`
--

LOCK TABLES `customer_loyalties` WRITE;
/*!40000 ALTER TABLE `customer_loyalties` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_loyalties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'customer',
  `layout_preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`layout_preferences`)),
  `remember_token` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'South Customer 01','0917000201','south.customer01@example.com','$2y$12$5i4EnaLOjlrlZx.JyFGzF.NpDFcbEOSBFQ8vdN9VBwd7Cm0rTpciG','customer',NULL,NULL,NULL,'2026-04-20 19:16:18','2026-04-20 19:16:18'),(2,'South Customer 02','0917000202','south.customer02@example.com','$2y$12$szDvUeQJ2DgK5czZbw5.XuoOd/966Sy.c8icIDgiKW9jm5WdtsNJ2','customer',NULL,NULL,NULL,'2026-04-20 19:16:18','2026-04-20 19:16:18'),(3,'South Customer 03','0917000203','south.customer03@example.com','$2y$12$UAAydmoT8sDa8ir0rHyiQej.pjyrMGS.Su9RVf.o6fduV8dsZwz4S','customer',NULL,NULL,NULL,'2026-04-20 19:16:18','2026-04-20 19:16:18'),(4,'South Customer 04','0917000204','south.customer04@example.com','$2y$12$9BvzFLL7.FvQYFdT7RCJ.Ol1Ajbrkf1TrgB4m36sLHGBseI9PM9we','customer',NULL,NULL,NULL,'2026-04-20 19:16:19','2026-04-20 19:16:19'),(5,'South Customer 05','0917000205','south.customer05@example.com','$2y$12$g4w3suh80dUtkJqubGhaN.tLV5QbPUKYWHBocwwgyDCn/7Nq/ByTW','customer',NULL,NULL,NULL,'2026-04-20 19:16:19','2026-04-20 19:16:19'),(6,'South Customer 06','0917000206','south.customer06@example.com','$2y$12$ZdC1EIwUZW90YtduZ4VSZ.boJBe0zMGd64t61WKlYmEWigWdPxtnq','customer',NULL,NULL,NULL,'2026-04-20 19:16:19','2026-04-20 19:16:19'),(7,'South Customer 07','0917000207','south.customer07@example.com','$2y$12$EA/X.OFgXW9UtLfYWux1ReZOQbGjrESyryP6RURcqmhbwzwhbW/8u','customer',NULL,NULL,NULL,'2026-04-20 19:16:20','2026-04-20 19:16:20'),(8,'South Customer 08','0917000208','south.customer08@example.com','$2y$12$9Kkh7OPjOfd21PsoLXa1HeWuB4lukyaa/3k7A0RUYxlFgoDWy8Kwi','customer',NULL,NULL,NULL,'2026-04-20 19:16:20','2026-04-20 19:16:20'),(9,'South Customer 09','0917000209','south.customer09@example.com','$2y$12$CYTq0D8/FEZ.7h7DjGade.83Kjqke3ghWSG.MoKMhiz80tNr9S0xm','customer',NULL,NULL,NULL,'2026-04-20 19:16:20','2026-04-20 19:16:20'),(10,'South Customer 10','0917000210','south.customer10@example.com','$2y$12$bdN59y/UtgE7JfBr.IumMecAmAcBnuiA9TBj37smUK7qi2Zlirbla','customer',NULL,NULL,NULL,'2026-04-20 19:16:21','2026-04-20 19:16:21');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL DEFAULT 'supplies',
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `expense_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_adjustments`
--

DROP TABLE IF EXISTS `inventory_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_adjustments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` bigint(20) unsigned NOT NULL,
  `adjustment_type` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `performed_by_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_adjustments_inventory_item_id_foreign` (`inventory_item_id`),
  CONSTRAINT `inventory_adjustments_inventory_item_id_foreign` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_adjustments`
--

LOCK TABLES `inventory_adjustments` WRITE;
/*!40000 ALTER TABLE `inventory_adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `unit` varchar(255) NOT NULL DEFAULT 'unit',
  `category` varchar(255) NOT NULL DEFAULT 'supplies',
  `description` text DEFAULT NULL,
  `quantity_on_hand` decimal(10,2) NOT NULL DEFAULT 0.00,
  `reorder_level` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cost_per_unit` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'2026_02_19_000001_create_customers_table',1),(3,'2026_02_19_000002_create_orders_table',1),(4,'2026_02_19_100001_create_services_table',1),(5,'2026_02_19_100002_add_service_and_payment_to_orders_table',1),(6,'2026_02_19_151237_update_orders_status_values',1),(7,'2026_02_19_152037_create_expenses_table',1),(8,'2026_02_19_173115_create_customer_loyalties_table',1),(9,'2026_02_19_180434_add_user_id_to_customers_table',1),(10,'2026_02_21_132915_add_password_column_in_customer_table',1),(11,'2026_02_21_150655_remove_address_column_from_table',1),(12,'2026_02_21_153602_add_remember_token_to_customers_table',1),(13,'2026_03_17_124814_add_layout_preferences_to_users_table',1),(14,'2026_03_17_124819_add_layout_preferences_to_customers_table',1),(15,'2026_03_18_072103_add_loyalty_award_columns_to_orders_table',1),(16,'2026_03_18_072103_create_notifications_table',1),(17,'2026_03_20_045623_create_inventory_items_table',1),(18,'2026_03_20_045626_create_inventory_adjustments_table',1),(19,'2026_03_20_050943_add_bundle_items_to_services_table',1),(20,'2026_03_20_050943_add_loyalty_redemption_to_orders_table',1),(21,'2026_04_02_063227_create_permissions_table',1),(22,'2026_04_02_063228_create_user_permissions_table',1),(23,'2026_04_02_103000_remove_order_permissions',1),(24,'2026_04_07_133946_create_roles_table',1),(25,'2026_04_07_133947_create_role_user_table',1),(26,'2026_04_07_133948_create_permission_role_table',1),(27,'2026_04_08_000000_modify_role_user_for_single_role',1),(28,'2026_04_15_055514_make_customer_password_nullable',1),(29,'2026_04_19_000000_restore_multiple_roles_per_user',1),(30,'2026_04_19_050000_rename_view_permissions_to_access',1),(31,'2026_04_20_000001_add_billing_cycle_to_orders',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `service_id` bigint(20) unsigned DEFAULT NULL,
  `weight` decimal(8,2) DEFAULT NULL,
  `order_number` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'received',
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`items`)),
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('unpaid','paid') NOT NULL DEFAULT 'unpaid',
  `loyalty_points_awarded` int(10) unsigned NOT NULL DEFAULT 0,
  `loyalty_points_awarded_at` timestamp NULL DEFAULT NULL,
  `loyalty_points_redeemed` int(10) unsigned NOT NULL DEFAULT 0,
  `loyalty_discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid_at` timestamp NULL DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `billing_cycle_start` timestamp NULL DEFAULT NULL,
  `billing_cycle_end` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_service_id_foreign` (`service_id`),
  KEY `idx_billing_cycle` (`billing_cycle_start`,`billing_cycle_end`),
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_role_permission_id_role_id_unique` (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,35,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(2,37,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(3,36,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(4,7,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(5,9,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(6,8,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(7,6,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(8,1,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(9,25,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(10,27,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(11,26,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(12,24,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(13,32,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(14,29,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(15,31,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(16,30,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(17,28,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(18,3,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(19,5,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(20,4,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(21,2,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(22,34,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(23,33,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(24,17,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(25,19,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(26,18,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(27,16,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(28,21,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(29,23,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(30,22,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(31,20,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(32,15,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(33,14,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(34,11,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(35,13,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(36,12,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(37,10,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(38,38,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(39,42,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(40,43,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(41,41,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(42,40,1,'2026-04-20 19:55:18','2026-04-20 19:55:18'),(43,39,1,'2026-04-20 19:55:18','2026-04-20 19:55:18');
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_key_unique` (`key`),
  KEY `permissions_module_index` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'dashboard.view','View Dashboard','dashboard','2026-04-20 19:55:18','2026-04-20 19:55:18'),(2,'orders.view','View Orders','orders','2026-04-20 19:55:18','2026-04-20 19:55:18'),(3,'orders.create','Create Orders','orders','2026-04-20 19:55:18','2026-04-20 19:55:18'),(4,'orders.update','Update Orders','orders','2026-04-20 19:55:18','2026-04-20 19:55:18'),(5,'orders.delete','Delete Orders','orders','2026-04-20 19:55:18','2026-04-20 19:55:18'),(6,'customers.view','View Customers','customers','2026-04-20 19:55:18','2026-04-20 19:55:18'),(7,'customers.create','Create Customers','customers','2026-04-20 19:55:18','2026-04-20 19:55:18'),(8,'customers.update','Update Customers','customers','2026-04-20 19:55:18','2026-04-20 19:55:18'),(9,'customers.delete','Delete Customers','customers','2026-04-20 19:55:18','2026-04-20 19:55:18'),(10,'staff.view','View Staff','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(11,'staff.create','Create Staff','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(12,'staff.update','Update Staff','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(13,'staff.delete','Delete Staff','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(14,'staff.assign_roles','Assign Staff Roles','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(15,'staff.assign_permissions','Assign Staff Permissions','staff','2026-04-20 19:55:18','2026-04-20 19:55:18'),(16,'roles.view','View Roles','roles','2026-04-20 19:55:18','2026-04-20 19:55:18'),(17,'roles.create','Create Roles','roles','2026-04-20 19:55:18','2026-04-20 19:55:18'),(18,'roles.update','Update Roles','roles','2026-04-20 19:55:18','2026-04-20 19:55:18'),(19,'roles.delete','Delete Roles','roles','2026-04-20 19:55:18','2026-04-20 19:55:18'),(20,'services.view','View Services','services','2026-04-20 19:55:18','2026-04-20 19:55:18'),(21,'services.create','Create Services','services','2026-04-20 19:55:18','2026-04-20 19:55:18'),(22,'services.update','Update Services','services','2026-04-20 19:55:18','2026-04-20 19:55:18'),(23,'services.delete','Delete Services','services','2026-04-20 19:55:18','2026-04-20 19:55:18'),(24,'expenses.view','View Expenses','expenses','2026-04-20 19:55:18','2026-04-20 19:55:18'),(25,'expenses.create','Create Expenses','expenses','2026-04-20 19:55:18','2026-04-20 19:55:18'),(26,'expenses.update','Update Expenses','expenses','2026-04-20 19:55:18','2026-04-20 19:55:18'),(27,'expenses.delete','Delete Expenses','expenses','2026-04-20 19:55:18','2026-04-20 19:55:18'),(28,'inventory.view','View Inventory','inventory','2026-04-20 19:55:18','2026-04-20 19:55:18'),(29,'inventory.create','Create Inventory Items','inventory','2026-04-20 19:55:18','2026-04-20 19:55:18'),(30,'inventory.update','Update Inventory Items','inventory','2026-04-20 19:55:18','2026-04-20 19:55:18'),(31,'inventory.delete','Delete Inventory Items','inventory','2026-04-20 19:55:18','2026-04-20 19:55:18'),(32,'inventory.adjust','Adjust Inventory Stock','inventory','2026-04-20 19:55:18','2026-04-20 19:55:18'),(33,'reports.view','View Reports','reports','2026-04-20 19:55:18','2026-04-20 19:55:18'),(34,'reports.export','Export Reports','reports','2026-04-20 19:55:18','2026-04-20 19:55:18'),(35,'analytics.view','View Analytics','analytics','2026-04-20 19:55:18','2026-04-20 19:55:18'),(36,'billing.view','View Billing','billing','2026-04-20 19:55:18','2026-04-20 19:55:18'),(37,'billing.download','Download Billing Documents','billing','2026-04-20 19:55:18','2026-04-20 19:55:18'),(38,'subscription.manage','Manage Subscription','billing','2026-04-20 19:55:18','2026-04-20 19:55:18'),(39,'updates.view','View Updates','updates','2026-04-20 19:55:18','2026-04-20 19:55:18'),(40,'updates.apply','Apply Updates','updates','2026-04-20 19:55:18','2026-04-20 19:55:18'),(41,'support.view','View Support Tickets','support','2026-04-20 19:55:18','2026-04-20 19:55:18'),(42,'support.create','Create Support Tickets','support','2026-04-20 19:55:18','2026-04-20 19:55:18'),(43,'support.reply','Reply to Support Tickets','support','2026-04-20 19:55:18','2026-04-20 19:55:18');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `assigned_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_user_role_id_user_id_unique` (`role_id`,`user_id`),
  KEY `role_user_assigned_by_foreign` (`assigned_by`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_assigned_by_foreign` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,NULL,'2026-04-20 19:16:17','2026-04-20 19:16:17');
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Owner','owner','Tenant owner with full access.','2026-04-20 19:16:16','2026-04-20 19:16:16'),(2,'Staff','staff','Tenant staff account.','2026-04-20 19:16:16','2026-04-20 19:16:16'),(3,'Customer','customer','Customer portal account.','2026-04-20 19:16:16','2026-04-20 19:16:16');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `bundle_items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`bundle_items`)),
  `price_type` enum('per_kilo','per_load','per_piece','flat') NOT NULL DEFAULT 'per_kilo',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `granted_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permissions_user_id_permission_id_unique` (`user_id`,`permission_id`),
  KEY `user_permissions_permission_id_foreign` (`permission_id`),
  KEY `user_permissions_granted_by_foreign` (`granted_by`),
  CONSTRAINT `user_permissions_granted_by_foreign` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'customer',
  `layout_preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`layout_preferences`)),
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'South Owner','2301106754+south@student.buksu.edu.ph',NULL,'$2y$12$f3HpVdo5Qn.M6LeoDUCmH.x.dDc9IEX69urfaYqqp.gmuMSHMBP/e','owner',NULL,NULL,'2026-04-20 19:16:17','2026-04-20 19:16:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-21 12:23:05
